def lambda_handler(event, context):
    # TODO implement
    return 'Hello, this is private lambda'